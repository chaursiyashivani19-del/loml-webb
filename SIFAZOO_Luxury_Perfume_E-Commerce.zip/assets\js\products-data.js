/**
 * SIFAZOO HAUTE PARFUMERIE — Master Product Catalog
 * Note: Specifications, prices, and reviews are clearly marked as sample/demonstration data
 * per brand guidelines until live merchant & laboratory records are connected.
 */

const SIFAZOO_PRODUCTS = [
  {
    id: "sifa-01",
    slug: "l-ombre-doree",
    name: "L'Ombre Dorée",
    subtitle: "Extrait de Parfum — 30% Olfactive Concentration",
    category: "unisex",
    categoryLabel: "Unisex Fragrance",
    family: "Woody Oriental",
    badge: "Signature Scent",
    isBestSeller: true,
    isFeatured: true,
    isNew: false,
    prices: {
      "50ml": 210,
      "100ml": 295,
      "200ml": 440
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.9,
    sampleReviewCount: 42,
    notes: {
      top: ["Calabrian Bergamot", "Saffron Threads", "Pink Pepper"],
      heart: ["Smoked Cambodian Oud", "Golden Amber Resin", "Turkish Damask Rose"],
      base: ["Bourbon Vanilla Infusion", "Aged Indonesian Patchouli", "Atlas Cedarwood"]
    },
    accords: ["Warm Spicy", "Smoky Woody", "Golden Amber", "Balsamic"],
    intensity: 5,
    longevity: "14+ Hours Longevity",
    sillage: "Enveloping & Sophisticated",
    season: "Autumn / Winter / Evening",
    description: "An intoxicating exploration of light and shadow. L'Ombre Dorée opens with radiant Calabrian bergamot and precious golden saffron, before descending into a nocturnal heart of smoked wild oud and caramelized resinous amber. Crafted for individuals who command presence without uttering a word.",
    ritual: "Mist across the collarbone, the nape of the neck, and the pulse points of the wrists. Allow the warm spirit of the amber to bloom undisturbed—avoid friction.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat. (SD Alcohol 40-B), Parfum (Fragrance), Aqua (Water), Limonene, Linalool, Alpha-Isomethyl Ionone, Eugenol, Citronellol, Geraniol, Coumarin, Benzyl Cinnamate. 80% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1000&q=85",
      "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1000&q=85",
      "https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?auto=format&fit=crop&w=1000&q=85"
    ]
  },
  {
    id: "sifa-02",
    slug: "rose-nocturne",
    name: "Rose Nocturne",
    subtitle: "Extrait de Parfum — Velvet Floral Chypree",
    category: "women",
    categoryLabel: "Women's Fragrance",
    family: "Floral",
    badge: "Bestseller",
    isBestSeller: true,
    isFeatured: true,
    isNew: false,
    prices: {
      "50ml": 195,
      "100ml": 280,
      "200ml": 415
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.95,
    sampleReviewCount: 38,
    notes: {
      top: ["Blackcurrant Nectar", "Italian Mandarin", "Crushed Violet Leaves"],
      heart: ["Centifolia Velvet Rose", "Black Périgord Truffle", "Night-Blooming Jasmine"],
      base: ["Smoked Papyrus", "Dark Cocoa Pod", "Sensual Cashmere Musk"]
    },
    accords: ["Velvety Rose", "Earthy Truffle", "Dark Woody", "Sensual Musk"],
    intensity: 4,
    longevity: "12+ Hours Longevity",
    sillage: "Alluring & Lingering",
    season: "All Seasons / Black Tie",
    description: "Far from conventional romantic roses, Rose Nocturne captures the midnight bloom of deep burgundy Grasse petals kissed by dark earthy truffles and velvety cocoa. An unapologetic homage to feminine mystique, passion, and sovereignty.",
    ritual: "Spray generously at the collarbone and let droplets fall upon clean silk or wool. Its multi-layered bouquet evolves continuously over twelve hours.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat., Parfum (Fragrance), Aqua, Geraniol, Citronellol, Hydroxycitronellal, Linalool, Farnesol, Benzyl Alcohol, Cinnamyl Alcohol. 78% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?auto=format&fit=crop&w=1000&q=85",
      "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1000&q=85",
      "https://images.unsplash.com/photo-1616949755610-8c9bbc08f138?auto=format&fit=crop&w=1000&q=85"
    ]
  },
  {
    id: "sifa-03",
    slug: "cuir-celeste",
    name: "Cuir Céleste",
    subtitle: "Eau de Parfum Intense — Modern Leather Architecture",
    category: "men",
    categoryLabel: "Men's Fragrance",
    family: "Leather",
    badge: "Atelier Edition",
    isBestSeller: true,
    isFeatured: true,
    isNew: false,
    prices: {
      "50ml": 220,
      "100ml": 310,
      "200ml": 460
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.88,
    sampleReviewCount: 29,
    notes: {
      top: ["Guatemalan Green Cardamom", "Bitter Almond", "Clary Sage"],
      heart: ["Tuscan Black Leather", "Cade Wood Smoke", "Florentine Orris Root"],
      base: ["Smoked Birch Tar", "White Ambergris", "Tonka Bean Absolute"]
    },
    accords: ["Smoky Leather", "Aromatic Spices", "Dry Woody", "Subtle Powder"],
    intensity: 5,
    longevity: "15+ Hours Longevity",
    sillage: "Authoritative & Refined",
    season: "Autumn / Winter / Formal",
    description: "Cuir Céleste is an architectural study in luxury leather. Raw Tuscan hide polished with roasted tonka, bitter almond, and powdery Florentine iris. A fragrance of quiet confidence, timeless tailoring, and undeniable magnetism.",
    ritual: "Apply directly to warm skin after grooming. Exceptional when layered over bespoke suiting.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat., Parfum, Aqua, Limonene, Coumarin, Evernia Prunastri (Oakmoss) Extract, Isoeugenol, Citral. 80% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=1000&q=85",
      "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=1000&q=85"
    ]
  },
  {
    id: "sifa-04",
    slug: "eclat-d-ambre",
    name: "Éclat d'Ambre",
    subtitle: "Extrait de Parfum — Golden Solar Resonance",
    category: "unisex",
    categoryLabel: "Unisex Fragrance",
    family: "Oriental",
    badge: "Customer Favorite",
    isBestSeller: true,
    isFeatured: true,
    isNew: false,
    prices: {
      "50ml": 190,
      "100ml": 275,
      "200ml": 395
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.92,
    sampleReviewCount: 34,
    notes: {
      top: ["Seville Candied Orange", "Davana Essence", "Cardamom"],
      heart: ["Rockrose Labdanum", "Wild Acacia Honey", "Benzoin Tears"],
      base: ["Fossilized Amber", "Sandalwood Cream", "Madagascar Vanilla Bean"]
    },
    accords: ["Resinous Amber", "Gourmand Honey", "Warm Balsamic", "Creamy Woods"],
    intensity: 4,
    longevity: "12+ Hours Longevity",
    sillage: "Warm & Magnetic",
    season: "All Year / Sunset & Evening",
    description: "Bottling the radiant warmth of golden hour. Éclat d'Ambre wraps the skin in melted amber resins, golden wildflower honey, and creamy Madagascan vanilla. An opulent second skin that invites proximity and lingers indefinitely.",
    ritual: "Disperse two sprays over the chest and behind the knees. Perfect for intimate evenings and cooler breezes.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat., Parfum, Aqua, Benzyl Benzoate, Cinnamal, Eugenol, Benzyl Salicylate. 79% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1000&q=85",
      "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1000&q=85"
    ]
  },
  {
    id: "sifa-05",
    slug: "velvet-santal",
    name: "Velvet Santal",
    subtitle: "Eau de Parfum — Meditative Modern Minimalist",
    category: "unisex",
    categoryLabel: "Unisex Fragrance",
    family: "Woody",
    badge: "New Release",
    isBestSeller: false,
    isFeatured: true,
    isNew: true,
    prices: {
      "50ml": 200,
      "100ml": 290,
      "200ml": 430
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.85,
    sampleReviewCount: 19,
    notes: {
      top: ["Violet Leaf", "Australian Blue Cypress", "Cardamom Pods"],
      heart: ["Sustainably Harvested Sandalwood", "Iris Pallida", "Papyrus"],
      base: ["White Musk", "Cedarwood Chips", "Golden Ambergris"]
    },
    accords: ["Powdery Iris", "Silky Sandalwood", "Clean Musk", "Green Violet"],
    intensity: 3,
    longevity: "10+ Hours Longevity",
    sillage: "Subtle & Intimate",
    season: "Spring / Summer / Everyday Signature",
    description: "The epitome of modern luxury minimalism. Velvet Santal is smooth, meditative, and effortlessly sophisticated. Creamy Australian sandalwood meets crystalline powdery iris and fresh dew-drenched violet leaves.",
    ritual: "Spray on pulse points and brush lightly through hair for an enduring whisper of elegance.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat., Parfum, Aqua, Alpha-Isomethyl Ionone, Farnesol, Linalool, Geraniol. 80% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=1000&q=85",
      "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1000&q=85"
    ]
  },
  {
    id: "sifa-06",
    slug: "santal-imperial",
    name: "Santal Impérial",
    subtitle: "Extrait de Parfum — Noble Smoked Woods",
    category: "men",
    categoryLabel: "Men's Fragrance",
    family: "Woody",
    badge: "Exclusive",
    isBestSeller: false,
    isFeatured: false,
    isNew: true,
    prices: {
      "50ml": 225,
      "100ml": 320,
      "200ml": 475
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.91,
    sampleReviewCount: 22,
    notes: {
      top: ["Black Pepper", "Calabrian Bergamot", "Juniper Berries"],
      heart: ["Haitian Vetiver", "Somalian Frankincense", "Nutmeg"],
      base: ["Aged Virginia Cedarwood", "Omani Myrrh", "Smoked Oak"]
    },
    accords: ["Smoky Frankincense", "Earthy Vetiver", "Noble Cedar", "Warm Spice"],
    intensity: 5,
    longevity: "14+ Hours Longevity",
    sillage: "Distinguished & Commanding",
    season: "Autumn / Winter / Executive",
    description: "A testament to regal poise and unwavering fortitude. Santal Impérial weaves ancient church frankincense with dark cedar timber and cracked black pepper. A masculine benchmark crafted for leaders.",
    ritual: "Apply to the neck and upper lapels for a distinguished aura that commands respect in every boardroom and salon.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat., Parfum, Aqua, Limonene, Eugenol, Isoeugenol, Linalool. 82% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1523293182086-7651a899d37f?auto=format&fit=crop&w=1000&q=85"
    ]
  },
  {
    id: "sifa-07",
    slug: "fleur-d-ivoire",
    name: "Fleur d'Ivoire",
    subtitle: "Eau de Parfum — Luminous White Floral Harmony",
    category: "women",
    categoryLabel: "Women's Fragrance",
    family: "Floral",
    badge: "Editorial Pick",
    isBestSeller: true,
    isFeatured: true,
    isNew: false,
    prices: {
      "50ml": 185,
      "100ml": 265,
      "200ml": 380
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.89,
    sampleReviewCount: 31,
    notes: {
      top: ["White Neroli Petals", "Dewy Pear", "Pink Freesia"],
      heart: ["Grasse Gardenia", "Indian Sambac Jasmine", "Tuberose Absolute"],
      base: ["Warm Cashmere Wood", "White Sandalwood", "Silky Musk"]
    },
    accords: ["Opulent White Floral", "Dewy Fresh", "Creamy Woods", "Luminous"],
    intensity: 4,
    longevity: "11+ Hours Longevity",
    sillage: "Radiant & Unforgettable",
    season: "Spring / Summer / Special Celebrations",
    description: "An homage to ivory silk and pristine petals. Fleur d'Ivoire captures the intoxicating brilliance of night-picked gardenia and Indian jasmine sambac, grounded by soft cashmere woods.",
    ritual: "Spray in an arch above your head and walk through the mist, allowing delicate floral molecules to veil your silhouette.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat., Parfum, Aqua, Benzyl Salicylate, Hydroxycitronellal, Hexyl Cinnamal, Linalool. 79% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1616949755610-8c9bbc08f138?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1616949755610-8c9bbc08f138?auto=format&fit=crop&w=1000&q=85",
      "https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?auto=format&fit=crop&w=1000&q=85"
    ]
  },
  {
    id: "sifa-08",
    slug: "nuit-mystique",
    name: "Nuit Mystique",
    subtitle: "Extrait de Parfum — Dark Boozy Plum & Incense",
    category: "men",
    categoryLabel: "Men's Fragrance",
    family: "Oriental",
    badge: "Rare Blend",
    isBestSeller: false,
    isFeatured: false,
    isNew: false,
    prices: {
      "50ml": 235,
      "100ml": 335,
      "200ml": 490
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.96,
    sampleReviewCount: 26,
    notes: {
      top: ["Dark Damson Plum", "Aged Caribbean Dark Rum", "Cinnamon Bark"],
      heart: ["Leather-Wrapped Incense", "Tobacco Smoke", "Roasted Cacao"],
      base: ["Peruvian Balsam", "Smoked Oud", "Bourbon Tonka"]
    },
    accords: ["Boozy Dark Plum", "Smoky Balsamic", "Rich Tobacco", "Deep Vanilla"],
    intensity: 5,
    longevity: "16+ Hours Longevity",
    sillage: "Enchanting & Heavy",
    season: "Winter / Nighttime Escapades",
    description: "A mysterious nocturnal composition. Velvety dark plum steeped in aged oak-barrel rum and swirling incense embers. Nuit Mystique is designed for the modern enigmatist who leaves questions unanswered.",
    ritual: "One to two sprays suffice on the inner elbows and base of throat. Its immense depth reveals itself in layers over 24 hours.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat., Parfum, Aqua, Coumarin, Eugenol, Benzyl Benzoate, Cinnamal. 81% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=1000&q=85"
    ]
  },
  {
    id: "sifa-09",
    slug: "soleil-de-grasse",
    name: "Soleil de Grasse",
    subtitle: "Eau de Parfum — Solar Citrus & Orange Blossom",
    category: "women",
    categoryLabel: "Women's Fragrance",
    family: "Fresh",
    badge: "Summer Sensation",
    isBestSeller: false,
    isFeatured: false,
    isNew: true,
    prices: {
      "50ml": 180,
      "100ml": 260,
      "200ml": 375
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.87,
    sampleReviewCount: 18,
    notes: {
      top: ["Riviera Sunlit Petitgrain", "Calabrian Bergamot", "Zesty Mandarin"],
      heart: ["Grasse Orange Blossom", "Luminant Neroli", "Pistachio Milk"],
      base: ["Solar Salty Ambergris", "Clean White Cedar", "Warm Skin Musk"]
    },
    accords: ["Solar Citrus", "Sparkling Neroli", "Golden Ambergris", "Clean Musk"],
    intensity: 3,
    longevity: "9+ Hours Longevity",
    sillage: "Airy & Euphoric",
    season: "Spring / Summer / Daylight",
    description: "The French Riviera bathed in crystalline afternoon light. Sparkling citrus orchards breeze over honeyed orange blossom fields and warm salty sun-warmed skin.",
    ritual: "Mist across the collar and hair on warm summer mornings before stepping out into the sunlight.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat., Parfum, Aqua, Limonene, Linalool, Citral, Geraniol. 78% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1595425970377-c9703cf48b6d?auto=format&fit=crop&w=1000&q=85"
    ]
  },
  {
    id: "sifa-10",
    slug: "iris-celeste",
    name: "Iris Céleste",
    subtitle: "Extrait de Parfum — Haute Florentine Orris",
    category: "unisex",
    categoryLabel: "Unisex Fragrance",
    family: "Floral",
    badge: "Haute Parfumerie",
    isBestSeller: false,
    isFeatured: true,
    isNew: false,
    prices: {
      "50ml": 240,
      "100ml": 340,
      "200ml": 510
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.97,
    sampleReviewCount: 15,
    notes: {
      top: ["Angelica Root Seeds", "Aldehydic Breeze", "Pink Peppercorn"],
      heart: ["Florentine Iris Pallida Butter (3-Year Aged)", "Suede Leather", "Dry Cedar"],
      base: ["Ambrette Seed Musk", "Dry Sandalwood", "Grey Ambergris"]
    },
    accords: ["Silken Orris", "Suede Powder", "Aldehydic Clean", "Precious Woods"],
    intensity: 4,
    longevity: "13+ Hours Longevity",
    sillage: "Couture & Whispering Luxury",
    season: "All Year / Sartorial Occasions",
    description: "Centuries of perfumery pedigree in a single flacon. Three-year aged Florentine Iris butter delivers an ethereal, silken suede texture that transcends trend. The ultimate connoisseur's choice.",
    ritual: "Gently dab onto pulse points. Let the warmth of your skin reveal the rare powdery heart.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat., Parfum, Aqua, Alpha-Isomethyl Ionone, Farnesol, Linalool. 83% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1587017539504-67cfbddac569?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1587017539504-67cfbddac569?auto=format&fit=crop&w=1000&q=85"
    ]
  },
  {
    id: "sifa-11",
    slug: "tobacco-royale",
    name: "Tobacco Royale",
    subtitle: "Extrait de Parfum — Golden Leaf & Charred Cedar",
    category: "men",
    categoryLabel: "Men's Fragrance",
    family: "Leather",
    badge: "Private Reserve",
    isBestSeller: false,
    isFeatured: false,
    isNew: false,
    prices: {
      "50ml": 215,
      "100ml": 315,
      "200ml": 465
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.9,
    sampleReviewCount: 24,
    notes: {
      top: ["Ginger Glaze", "Cardamom", "Star Anise"],
      heart: ["Cuban Tobacco Leaves", "Honeyed Osmanthus", "Clove Bud"],
      base: ["Charred Cedarwood", "Smoked Tonka Bean", "Precious Amber"]
    },
    accords: ["Honeyed Tobacco", "Warm Spices", "Smoked Wood", "Gourmand"],
    intensity: 5,
    longevity: "15+ Hours Longevity",
    sillage: "Warm & Rich",
    season: "Autumn / Winter / Evening",
    description: "Sun-cured tobacco leaf laced with spiced mountain honey and charred cedar embers. A masterclass in warmth, prestige, and distinguished ease.",
    ritual: "Spray on the chest and pulse points before formal evening gatherings.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat., Parfum, Aqua, Coumarin, Eugenol, Cinnamal, Limonene. 81% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1582211594533-268f4f1edcb9?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1582211594533-268f4f1edcb9?auto=format&fit=crop&w=1000&q=85"
    ]
  },
  {
    id: "sifa-12",
    slug: "musc-pur",
    name: "Musc Pur",
    subtitle: "Eau de Parfum — Second Skin Purity",
    category: "unisex",
    categoryLabel: "Unisex Fragrance",
    family: "Fresh",
    badge: "Modern Classic",
    isBestSeller: false,
    isFeatured: false,
    isNew: false,
    prices: {
      "50ml": 175,
      "100ml": 250,
      "200ml": 360
    },
    defaultSize: "100ml",
    sampleNotice: "Sample product profile & indicative pricing for demonstration",
    sampleRating: 4.86,
    sampleReviewCount: 20,
    notes: {
      top: ["White Aldehydes", "Bergamot Zest", "Linen Petals"],
      heart: ["Clean White Musk", "Ambrette Seed", "Dewy Peony"],
      base: ["Cashmeran", "Sheer Sandalwood", "Blonde Woods"]
    },
    accords: ["Clean Linen", "Skin Musk", "Soft Powder", "Sheer Woods"],
    intensity: 2,
    longevity: "8+ Hours Longevity",
    sillage: "Whispering & Clean",
    season: "All Year / Pure Daily Luxury",
    description: "The sensory beauty of pristine crisp white linen dried in gentle morning air. Musc Pur melds seamlessly with your natural chemistry to create an intimate, intoxicating signature that feels uniquely yours.",
    ritual: "Spray liberally after bathing onto warm, hydrated skin.",
    ingredientsNotice: "Formulated in Grasse, France under strict IFRA safety guidelines.",
    ingredients: "Alcohol Denat., Parfum, Aqua, Alpha-Isomethyl Ionone, Hydroxycitronellal, Limonene. 78% Vol.",
    primaryImage: "https://images.unsplash.com/photo-1615397349754-cfa2066a298e?auto=format&fit=crop&w=1000&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1615397349754-cfa2066a298e?auto=format&fit=crop&w=1000&q=85"
    ]
  }
];

// Helper functions for easy querying
const SifazooCatalog = {
  getAll: () => SIFAZOO_PRODUCTS,
  getById: (id) => SIFAZOO_PRODUCTS.find(p => p.id === id),
  getBySlug: (slug) => SIFAZOO_PRODUCTS.find(p => p.slug === slug),
  getByCategory: (category) => {
    if (!category || category === "all") return SIFAZOO_PRODUCTS;
    return SIFAZOO_PRODUCTS.filter(p => p.category.toLowerCase() === category.toLowerCase());
  },
  getBestSellers: () => SIFAZOO_PRODUCTS.filter(p => p.isBestSeller),
  getFeatured: () => SIFAZOO_PRODUCTS.filter(p => p.isFeatured),
  getRelated: (productId, limit = 3) => {
    const current = SIFAZOO_PRODUCTS.find(p => p.id === productId);
    if (!current) return SIFAZOO_PRODUCTS.slice(0, limit);
    return SIFAZOO_PRODUCTS
      .filter(p => p.id !== productId && (p.category === current.category || p.family === current.family))
      .slice(0, limit);
  }
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = { SIFAZOO_PRODUCTS, SifazooCatalog };
}


/**
 * SIFAZOO HAUTE PARFUMERIE — Client-Side Router & View Controller
 * Manages all 15 pages and deep linking with seamless transitions.
 */

class SifazooRouter {
  constructor() {
    this.routes = {
      '': () => this.showView('view-home'),
      'home': () => this.showView('view-home'),
      'shop': (params) => this.showShop('all', params),
      'men': (params) => this.showShop('men', params),
      'women': (params) => this.showShop('women', params),
      'unisex': (params) => this.showShop('unisex', params),
      'product': (params) => this.showProductDetail(params),
      'about': () => this.showView('view-about'),
      'contact': () => this.showView('view-contact'),
      'cart': () => this.showView('view-cart'),
      'checkout': () => this.showView('view-checkout'),
      'wishlist': () => this.showView('view-wishlist'),
      'faq': () => this.showView('view-faq'),
      'shipping': () => this.showView('view-shipping'),
      'privacy': () => this.showView('view-privacy'),
      'terms': () => this.showView('view-terms')
    };

    this.currentViewId = null;
    this.init();
  }

  init() {
    window.addEventListener('hashchange', () => this.handleRouting());
    window.addEventListener('load', () => this.handleRouting());
    
    // Intercept navigation links
    document.addEventListener('click', (e) => {
      const link = e.target.closest('a[href^="#"]');
      if (link) {
        const hash = link.getAttribute('href').substring(1);
        if (hash) {
          // If already on page, scroll smoothly to top
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      }
    });
  }

  handleRouting() {
    const rawHash = window.location.hash.replace(/^#\/?/, '');
    const [path, ...paramParts] = rawHash.split('/');
    const params = paramParts.join('/');

    // Check query params if any
    const routeHandler = this.routes[path.toLowerCase()] || this.routes[''];
    if (typeof routeHandler === 'function') {
      routeHandler(params);
    } else {
      this.showView('view-home');
    }

    // Update active nav links
    this.updateActiveNavLinks(path || 'home');
  }

  showView(viewId) {
    const views = document.querySelectorAll('.page-view');
    views.forEach(v => {
      v.style.display = 'none';
      v.classList.remove('is-active');
    });

    const targetView = document.getElementById(viewId);
    if (targetView) {
      targetView.style.display = 'block';
      setTimeout(() => targetView.classList.add('is-active'), 20);
      this.currentViewId = viewId;
    }

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Close any open drawers or modals
    window.sifazooApp?.closeAllOverlays();
  }

  showShop(category = 'all', sortParam = '') {
    this.showView('view-shop');
    if (window.sifazooApp) {
      window.sifazooApp.filterShop(category, sortParam);
    }
  }

  showProductDetail(productId) {
    this.showView('view-product-detail');
    if (window.sifazooApp) {
      window.sifazooApp.renderProductDetailPage(productId || 'sifa-01');
    }
  }

  updateActiveNavLinks(route) {
    document.querySelectorAll('.nav-link').forEach(link => {
      const href = link.getAttribute('href') || '';
      const target = href.replace(/^#\/?/, '').toLowerCase();
      if (target === route || (route === '' && target === 'home')) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }
}

window.sifazooRouter = new SifazooRouter();


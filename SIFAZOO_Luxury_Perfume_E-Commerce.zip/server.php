<?php
/**
 * SIFAZOO HAUTE PARFUMERIE — Backend API & Web Server Router
 * Provides REST API endpoints and static file routing for PHP's built-in server.
 */

// Set headers for CORS and JSON where applicable
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
$method = $_SERVER['REQUEST_METHOD'];

// Handle REST API Endpoints
if (strpos($uri, '/api/') === 0) {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');

    if ($method === 'OPTIONS') {
        http_response_code(200);
        exit;
    }

    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true) ?? $_POST;

    // 1. Newsletter Subscription API
    if ($uri === '/api/newsletter' && $method === 'POST') {
        $email = filter_var($data['email'] ?? '', FILTER_VALIDATE_EMAIL);
        if (!$email) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Please provide a valid email address.'
            ]);
            exit;
        }

        // Log into newsletter subscribers store
        $subscribersFile = __DIR__ . '/data_subscribers.json';
        $subscribers = file_exists($subscribersFile) ? json_decode(file_get_contents($subscribersFile), true) : [];
        if (!in_array($email, $subscribers)) {
            $subscribers[] = [
                'email' => $email,
                'subscribed_at' => date('c'),
                'privilege_code' => 'SIFAZOO10'
            ];
            file_put_contents($subscribersFile, json_encode($subscribers, JSON_PRETTY_PRINT));
        }

        echo json_encode([
            'success' => true,
            'message' => 'Welcome to SIFAZOO. Your 10% welcome privilege code is SIFAZOO10.'
        ]);
        exit;
    }

    // 2. Concierge Contact Inquiries API
    if ($uri === '/api/contact' && $method === 'POST') {
        $name = trim($data['name'] ?? '');
        $email = filter_var($data['email'] ?? '', FILTER_VALIDATE_EMAIL);
        $subject = trim($data['subject'] ?? 'Consultation');
        $message = trim($data['message'] ?? '');

        if (!$name || !$email || !$message) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Please complete all required fields.'
            ]);
            exit;
        }

        $inquiriesFile = __DIR__ . '/data_inquiries.json';
        $inquiries = file_exists($inquiriesFile) ? json_decode(file_get_contents($inquiriesFile), true) : [];
        $ticketId = 'SFZ-TKT-' . date('Ymd') . '-' . rand(100, 999);
        $inquiries[] = [
            'ticket_id' => $ticketId,
            'name' => htmlspecialchars($name),
            'email' => $email,
            'subject' => htmlspecialchars($subject),
            'message' => htmlspecialchars($message),
            'received_at' => date('c'),
            'status' => 'Pending Concierge Review'
        ];
        file_put_contents($inquiriesFile, json_encode($inquiries, JSON_PRETTY_PRINT));

        echo json_encode([
            'success' => true,
            'ticket_id' => $ticketId,
            'message' => 'Your inquiry has been received. Our concierge desk will respond within 4 business hours.'
        ]);
        exit;
    }

    // 3. Demonstration Order Placement API
    if ($uri === '/api/order' && $method === 'POST') {
        $orderId = 'SFZ-' . rand(100000, 999999);
        $ordersFile = __DIR__ . '/data_orders.json';
        $orders = file_exists($ordersFile) ? json_decode(file_get_contents($ordersFile), true) : [];

        $orderRecord = [
            'order_id' => $orderId,
            'type' => 'Demonstration Mode Order',
            'client_name' => htmlspecialchars($data['name'] ?? 'Distinguished Patron'),
            'client_email' => filter_var($data['email'] ?? 'patron@example.com', FILTER_SANITIZE_EMAIL),
            'destination' => htmlspecialchars(($data['address'] ?? '') . ', ' . ($data['city'] ?? '') . ', ' . ($data['country'] ?? '')),
            'items' => $data['items'] ?? [],
            'subtotal' => floatval($data['subtotal'] ?? 0),
            'total' => floatval($data['total'] ?? 0),
            'created_at' => date('c'),
            'note' => 'DEMONSTRATION ORDER — Real gateway connects upon merchant credential configuration.'
        ];

        $orders[] = $orderRecord;
        file_put_contents($ordersFile, json_encode($orders, JSON_PRETTY_PRINT));

        echo json_encode([
            'success' => true,
            'order_id' => $orderId,
            'order' => $orderRecord,
            'message' => 'Order logged successfully in demonstration mode.'
        ]);
        exit;
    }

    // Default 404 for unknown API
    http_response_code(404);
    echo json_encode(['error' => 'API route not found']);
    exit;
}

// Static File Routing for PHP Built-In Server
$filePath = __DIR__ . $uri;

if ($uri !== '/' && file_exists($filePath) && !is_dir($filePath)) {
    // Deliver static file with appropriate content-type
    $ext = pathinfo($filePath, PATHINFO_EXTENSION);
    $mimes = [
        'html' => 'text/html; charset=utf-8',
        'css'  => 'text/css; charset=utf-8',
        'js'   => 'application/javascript; charset=utf-8',
        'json' => 'application/json; charset=utf-8',
        'svg'  => 'image/svg+xml',
        'png'  => 'image/png',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'webp' => 'image/webp',
        'xml'  => 'application/xml',
        'txt'  => 'text/plain'
    ];

    if (isset($mimes[$ext])) {
        header('Content-Type: ' . $mimes[$ext]);
    }
    readfile($filePath);
    exit;
}

// Fallback to index.html
include __DIR__ . '/index.html';


/**
 * SIFAZOO HAUTE PARFUMERIE — Master Application Controller
 * Handles interactive components, grids, modals, quiz, cart drawer, and checkout.
 */

class SifazooApp {
  constructor() {
    this.currentCategory = 'all';
    this.currentSort = 'featured';
    this.currentPdpProduct = null;
    this.currentPdpSize = '100ml';
    this.currentPdpQty = 1;
    this.init();
  }

  init() {
    // Subscribe store updates to sync badges and cart drawer
    window.sifazooStore.subscribe(() => {
      this.updateBadges();
      this.renderCartDrawer();
      this.renderCartPage();
      this.renderWishlistPage();
      this.renderCheckoutSummary();
    });

    this.bindEvents();
    this.renderBestSellers();
    this.updateBadges();
    this.renderCartDrawer();

    // Check URL parameters for direct product linking
    const urlParams = new URLSearchParams(window.location.search);
    const prodParam = urlParams.get('id');
    if (prodParam) {
      window.location.hash = `#product/${prodParam}`;
    }
  }

  bindEvents() {
    // Header Scroll effect
    window.addEventListener('scroll', () => {
      const header = document.querySelector('.site-header');
      if (header) {
        if (window.scrollY > 20) {
          header.classList.add('is-scrolled');
        } else {
          header.classList.remove('is-scrolled');
        }
      }
    });

    // Mobile Menu Toggle
    const menuToggle = document.getElementById('menu-toggle');
    const mobileMenu = document.getElementById('mobile-menu');
    const mobileMenuClose = document.getElementById('mobile-menu-close');
    
    if (menuToggle && mobileMenu) {
      menuToggle.addEventListener('click', () => {
        mobileMenu.classList.add('is-open');
        document.body.style.overflow = 'hidden';
      });
    }

    if (mobileMenuClose && mobileMenu) {
      mobileMenuClose.addEventListener('click', () => {
        mobileMenu.classList.remove('is-open');
        document.body.style.overflow = '';
      });
    }

    // Cart Drawer Toggle
    const cartToggleBtns = document.querySelectorAll('.cart-toggle-btn');
    const cartDrawer = document.getElementById('cart-drawer');
    const cartBackdrop = document.getElementById('cart-backdrop');
    const cartCloseBtn = document.getElementById('cart-close-btn');

    cartToggleBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openCartDrawer();
      });
    });

    if (cartCloseBtn) {
      cartCloseBtn.addEventListener('click', () => this.closeCartDrawer());
    }

    if (cartBackdrop) {
      cartBackdrop.addEventListener('click', () => {
        this.closeCartDrawer();
        this.closeAllOverlays();
      });
    }

    // Search Modal Toggle
    const searchToggleBtns = document.querySelectorAll('.search-toggle-btn');
    const searchModal = document.getElementById('search-modal');
    const searchCloseBtn = document.getElementById('search-close-btn');
    const searchInput = document.getElementById('search-input');

    searchToggleBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openSearchModal();
      });
    });

    if (searchCloseBtn) {
      searchCloseBtn.addEventListener('click', () => this.closeSearchModal());
    }

    if (searchInput) {
      searchInput.addEventListener('input', (e) => this.handleSearch(e.target.value));
    }

    // Scent Finder Quiz Triggers
    const quizTriggers = document.querySelectorAll('.quiz-trigger-btn');
    quizTriggers.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        this.openQuizModal();
      });
    });

    const quizClose = document.getElementById('quiz-close-btn');
    if (quizClose) {
      quizClose.addEventListener('click', () => this.closeQuizModal());
    }

    // Quick View Modal Close
    const qvModal = document.getElementById('quick-view-modal');
    const qvClose = document.getElementById('quick-view-close-btn');
    if (qvClose && qvModal) {
      qvClose.addEventListener('click', () => {
        qvModal.classList.remove('is-open');
      });
    }

    // Newsletter Forms
    document.querySelectorAll('.newsletter-form').forEach(form => {
      form.addEventListener('submit', (e) => this.handleNewsletterSubmit(e));
    });

    // Contact Form
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
      contactForm.addEventListener('submit', (e) => this.handleContactSubmit(e));
    }

    // Checkout Form
    const checkoutForm = document.getElementById('checkout-form');
    if (checkoutForm) {
      checkoutForm.addEventListener('submit', (e) => this.handleCheckoutSubmit(e));
    }

    // Filter controls in shop
    const sortSelect = document.getElementById('shop-sort-select');
    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        this.currentSort = e.target.value;
        this.renderShopGrid();
      });
    }
  }

  // --- OVERLAYS & MODALS ---
  openCartDrawer() {
    const drawer = document.getElementById('cart-drawer');
    const backdrop = document.getElementById('cart-backdrop');
    if (drawer && backdrop) {
      drawer.classList.add('is-open');
      backdrop.classList.add('is-open');
      document.body.style.overflow = 'hidden';
    }
  }

  closeCartDrawer() {
    const drawer = document.getElementById('cart-drawer');
    const backdrop = document.getElementById('cart-backdrop');
    if (drawer && backdrop) {
      drawer.classList.remove('is-open');
      backdrop.classList.remove('is-open');
      document.body.style.overflow = '';
    }
  }

  openSearchModal() {
    const modal = document.getElementById('search-modal');
    const input = document.getElementById('search-input');
    if (modal) {
      modal.classList.add('is-open');
      document.body.style.overflow = 'hidden';
      if (input) {
        setTimeout(() => input.focus(), 150);
      }
    }
  }

  closeSearchModal() {
    const modal = document.getElementById('search-modal');
    if (modal) {
      modal.classList.remove('is-open');
      document.body.style.overflow = '';
    }
  }

  closeAllOverlays() {
    this.closeCartDrawer();
    this.closeSearchModal();
    const qvModal = document.getElementById('quick-view-modal');
    if (qvModal) qvModal.classList.remove('is-open');
    const quizModal = document.getElementById('quiz-modal');
    if (quizModal) quizModal.classList.remove('is-open');
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenu) mobileMenu.classList.remove('is-open');
    document.body.style.overflow = '';
  }

  // --- BADGES SYNC ---
  updateBadges() {
    const cartCount = window.sifazooStore.getCartCount();
    const wishlistCount = window.sifazooStore.getWishlistCount();

    document.querySelectorAll('.cart-count-badge').forEach(el => {
      el.textContent = cartCount;
      el.style.display = cartCount > 0 ? 'flex' : 'none';
    });

    document.querySelectorAll('.wishlist-count-badge').forEach(el => {
      el.textContent = wishlistCount;
      el.style.display = wishlistCount > 0 ? 'flex' : 'none';
    });
  }

  // --- PRODUCT CARDS GENERATOR ---
  createProductCardHTML(product) {
    const isWishlisted = window.sifazooStore.isInWishlist(product.id);
    const price = product.prices['100ml'];

    return `
      <article class="product-card" data-id="${product.id}">
        <div class="product-card-media">
          <a href="#product/${product.id}">
            <img src="${product.primaryImage}" alt="${product.name} luxury perfume flacon" loading="lazy" />
          </a>
          ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ''}
          <button class="wishlist-toggle-btn ${isWishlisted ? 'is-active' : ''}" 
                  data-action="wishlist" data-id="${product.id}" 
                  aria-label="Save ${product.name} to wishlist">
            <svg viewBox="0 0 24 24" fill="${isWishlisted ? 'currentColor' : 'none'}" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" 
                    d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
            </svg>
          </button>
          <div class="product-quick-view-overlay">
            <button class="quick-view-btn" data-action="quickview" data-id="${product.id}">
              Quick View
            </button>
          </div>
        </div>
        <div class="product-card-body">
          <div class="product-category-family">${product.categoryLabel} · ${product.family}</div>
          <h3 class="product-title">
            <a href="#product/${product.id}">${product.name}</a>
          </h3>
          <p class="product-subtitle-text">${product.notes.heart.join(', ')}</p>
          <div class="product-price-row">
            <span class="product-price">$${price}</span>
            <span class="product-size-label">100 ML</span>
          </div>
          <div class="product-rating-box">
            <span class="product-rating-stars">★★★★★</span>
            <span>${product.sampleRating} <span style="opacity:0.6">(${product.sampleReviewCount} client trials*)</span></span>
          </div>
          <div class="product-card-actions">
            <button class="product-card-add-btn" data-action="add-cart" data-id="${product.id}" data-size="100ml">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
              </svg>
              Add to Bag
            </button>
          </div>
        </div>
      </article>
    `;
  }

  // --- BEST SELLERS GRID (HOMEPAGE) ---
  renderBestSellers() {
    const container = document.getElementById('bestsellers-grid');
    if (!container) return;

    const bestSellers = SifazooCatalog.getBestSellers().slice(0, 4);
    container.innerHTML = bestSellers.map(p => this.createProductCardHTML(p)).join('');
    this.attachCardInteractions(container);
  }

  // --- SHOP ALL & CATEGORY VIEWS ---
  filterShop(category = 'all', sort = 'featured') {
    this.currentCategory = category;
    this.currentSort = sort || 'featured';

    // Update filter pills active state
    document.querySelectorAll('.filter-pill').forEach(pill => {
      const cat = pill.getAttribute('data-category');
      if (cat === category) {
        pill.classList.add('is-active');
      } else {
        pill.classList.remove('is-active');
      }
    });

    // Update shop title
    const titleEl = document.getElementById('shop-page-title');
    const descEl = document.getElementById('shop-page-desc');
    if (titleEl) {
      if (category === 'men') {
        titleEl.textContent = "Men's Fragrances";
        if (descEl) descEl.textContent = "Architectural leather, noble woods, and smoked incense tailored for commanding poise.";
      } else if (category === 'women') {
        titleEl.textContent = "Women's Fragrances";
        if (descEl) descEl.textContent = "Intoxicating centifolia florals, rare Madagascan vanillas, and velvet evening accords.";
      } else if (category === 'unisex') {
        titleEl.textContent = "Unisex Fragrances";
        if (descEl) descEl.textContent = "Genderless olfactive poetry: pure orris, mineral amber, and sacred woods.";
      } else {
        titleEl.textContent = "The Complete Haute Parfumerie Collection";
        if (descEl) descEl.textContent = "Explore every signature flacon meticulously blended in Grasse, France.";
      }
    }

    this.renderShopGrid();
  }

  renderShopGrid() {
    const grid = document.getElementById('shop-products-grid');
    if (!grid) return;

    let products = SifazooCatalog.getByCategory(this.currentCategory);

    // Apply sorting
    if (this.currentSort === 'price-asc') {
      products = [...products].sort((a, b) => a.prices['100ml'] - b.prices['100ml']);
    } else if (this.currentSort === 'price-desc') {
      products = [...products].sort((a, b) => b.prices['100ml'] - a.prices['100ml']);
    } else if (this.currentSort === 'newest') {
      products = [...products].sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
    }

    grid.innerHTML = products.map(p => this.createProductCardHTML(p)).join('');
    this.attachCardInteractions(grid);

    const countEl = document.getElementById('shop-product-count');
    if (countEl) {
      countEl.textContent = `Displaying ${products.length} Creation${products.length > 1 ? 's' : ''}`;
    }
  }

  attachCardInteractions(container) {
    if (!container) return;

    // Wishlist Buttons
    container.querySelectorAll('[data-action="wishlist"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        const isAdded = window.sifazooStore.toggleWishlist(id);
        btn.classList.toggle('is-active', isAdded);
        const svg = btn.querySelector('svg');
        if (svg) svg.setAttribute('fill', isAdded ? 'currentColor' : 'none');
      });
    });

    // Add To Bag Buttons
    container.querySelectorAll('[data-action="add-cart"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        const size = btn.getAttribute('data-size') || '100ml';
        window.sifazooStore.addToCart(id, size, 1);
        this.openCartDrawer();
      });
    });

    // Quick View Buttons
    container.querySelectorAll('[data-action="quickview"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        this.openQuickView(id);
      });
    });
  }

  // --- QUICK VIEW MODAL ---
  openQuickView(productId) {
    const product = SifazooCatalog.getById(productId);
    if (!product) return;

    const modal = document.getElementById('quick-view-modal');
    const container = document.getElementById('quick-view-content');
    if (!modal || !container) return;

    let selectedSize = '100ml';
    let currentQty = 1;

    container.innerHTML = `
      <div class="quick-view-grid">
        <div class="quick-view-media">
          <img src="${product.primaryImage}" alt="${product.name}" id="qv-img" />
        </div>
        <div class="quick-view-details">
          <div class="pdp-family-badge">${product.categoryLabel} · ${product.family}</div>
          <h2 class="pdp-title" style="font-size:1.8rem; margin-bottom:4px;">${product.name}</h2>
          <p class="pdp-subtitle" style="font-size:0.85rem; margin-bottom:12px;">${product.subtitle}</p>
          <div class="pdp-price" id="qv-price" style="font-size:1.5rem; margin-bottom:18px;">$${product.prices[selectedSize]}</div>
          
          <p style="font-size:0.85rem; color:#666; line-height:1.6; margin-bottom:20px;">
            ${product.description}
          </p>

          <div style="margin-bottom:18px;">
            <div style="font-size:0.72rem; letter-spacing:0.18em; text-transform:uppercase; font-weight:600; margin-bottom:8px;">
              SELECT FLACON VOLUME:
            </div>
            <div style="display:flex; gap:8px;">
              ${Object.keys(product.prices).map(size => `
                <button class="size-btn ${size === selectedSize ? 'is-selected' : ''}" data-qv-size="${size}" style="padding:8px 12px; flex:1;">
                  <span class="size-name">${size}</span>
                  <span class="size-price-tag">$${product.prices[size]}</span>
                </button>
              `).join('')}
            </div>
          </div>

          <div style="display:grid; grid-template-columns:auto 1fr; gap:10px; margin-bottom:18px;">
            <div class="pdp-qty-wrap">
              <button class="pdp-qty-btn" id="qv-qty-minus">-</button>
              <span class="pdp-qty-display" id="qv-qty-num">${currentQty}</span>
              <button class="pdp-qty-btn" id="qv-qty-plus">+</button>
            </div>
            <button class="btn btn--burgundy pdp-add-btn" id="qv-add-cart-btn">
              Add to Bag · <span id="qv-btn-price">$${product.prices[selectedSize]}</span>
            </button>
          </div>

          <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #eee; padding-top:12px;">
            <a href="#product/${product.id}" class="btn--text-link" id="qv-full-detail-link">View Complete Olfactory Details</a>
            <span style="font-size:0.68rem; color:#888;">Complimentary Insured Shipping</span>
          </div>
        </div>
      </div>
    `;

    // Size Selection Handlers
    container.querySelectorAll('[data-qv-size]').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('[data-qv-size]').forEach(b => b.classList.remove('is-selected'));
        btn.classList.add('is-selected');
        selectedSize = btn.getAttribute('data-qv-size');
        const p = product.prices[selectedSize];
        container.querySelector('#qv-price').textContent = `$${p}`;
        container.querySelector('#qv-btn-price').textContent = `$${p * currentQty}`;
      });
    });

    // Quantity Handlers
    container.querySelector('#qv-qty-minus').addEventListener('click', () => {
      if (currentQty > 1) {
        currentQty--;
        container.querySelector('#qv-qty-num').textContent = currentQty;
        container.querySelector('#qv-btn-price').textContent = `$${product.prices[selectedSize] * currentQty}`;
      }
    });

    container.querySelector('#qv-qty-plus').addEventListener('click', () => {
      currentQty++;
      container.querySelector('#qv-qty-num').textContent = currentQty;
      container.querySelector('#qv-btn-price').textContent = `$${product.prices[selectedSize] * currentQty}`;
    });

    // Add to Cart
    container.querySelector('#qv-add-cart-btn').addEventListener('click', () => {
      window.sifazooStore.addToCart(product.id, selectedSize, currentQty);
      modal.classList.remove('is-open');
      this.openCartDrawer();
    });

    // Full detail link
    container.querySelector('#qv-full-detail-link').addEventListener('click', () => {
      modal.classList.remove('is-open');
    });

    modal.classList.add('is-open');
  }

  // --- PRODUCT DETAIL PAGE (FULL VIEW) ---
  renderProductDetailPage(productId) {
    const product = SifazooCatalog.getById(productId) || SifazooCatalog.getById('sifa-01');
    this.currentPdpProduct = product;
    this.currentPdpSize = product.defaultSize || '100ml';
    this.currentPdpQty = 1;

    const container = document.getElementById('pdp-view-container');
    if (!container) return;

    const isWishlisted = window.sifazooStore.isInWishlist(product.id);
    const related = SifazooCatalog.getRelated(product.id, 3);

    container.innerHTML = `
      <div class="container">
        <nav class="breadcrumbs" style="justify-content:flex-start; margin-bottom:28px;">
          <a href="#home">Home</a>
          <span class="separator">/</span>
          <a href="#shop">Collection</a>
          <span class="separator">/</span>
          <a href="#${product.category}">${product.categoryLabel}</a>
          <span class="separator">/</span>
          <span style="color:var(--color-black); font-weight:600;">${product.name}</span>
        </nav>

        <div class="pdp-grid">
          <!-- Gallery -->
          <div class="pdp-gallery">
            <div class="pdp-main-image-wrap">
              <img id="pdp-main-img" src="${product.primaryImage}" alt="${product.name} luxury bottle photography" />
              ${product.badge ? `<span class="product-badge" style="top:20px; left:20px;">${product.badge}</span>` : ''}
            </div>
            <div class="pdp-thumbnails">
              ${product.galleryImages.map((imgUrl, idx) => `
                <button class="pdp-thumb-btn ${idx === 0 ? 'is-active' : ''}" data-thumb="${imgUrl}">
                  <img src="${imgUrl}" alt="${product.name} angle view ${idx + 1}" />
                </button>
              `).join('')}
            </div>
          </div>

          <!-- Product Specifications & Buy Form -->
          <div class="pdp-content">
            <div class="pdp-header">
              <div class="pdp-family-badge">${product.categoryLabel} · ${product.family}</div>
              <h1 class="pdp-title">${product.name}</h1>
              <p class="pdp-subtitle">${product.subtitle}</p>
              <div class="product-rating-box" style="margin-bottom:14px;">
                <span class="product-rating-stars">★★★★★</span>
                <span>${product.sampleRating} / 5.0</span>
                <span style="color:var(--color-gray-400)">(${product.sampleReviewCount} client sample trials*)</span>
              </div>
              <div class="pdp-price" id="pdp-current-price">$${product.prices[this.currentPdpSize]}</div>
            </div>

            <!-- Size Selector -->
            <div class="pdp-size-selector-label">
              <span>Select Flacon Volume:</span>
              <span id="pdp-selected-size-label" style="color:var(--color-burgundy);">${this.currentPdpSize} Extrait</span>
            </div>
            <div class="pdp-size-buttons">
              ${Object.keys(product.prices).map(size => `
                <button class="size-btn ${size === this.currentPdpSize ? 'is-selected' : ''}" data-pdp-size="${size}">
                  <span class="size-name">${size}</span>
                  <span class="size-price-tag">$${product.prices[size]}</span>
                </button>
              `).join('')}
            </div>

            <!-- Add to Cart & Actions -->
            <div class="pdp-actions-row">
              <div class="pdp-qty-wrap">
                <button class="pdp-qty-btn" id="pdp-qty-dec">-</button>
                <span class="pdp-qty-display" id="pdp-qty-val">${this.currentPdpQty}</span>
                <button class="pdp-qty-btn" id="pdp-qty-inc">+</button>
              </div>
              <button class="btn btn--burgundy pdp-add-btn" id="pdp-submit-add">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
                </svg>
                Add to Bag
              </button>
              <button class="pdp-wishlist-btn ${isWishlisted ? 'is-active' : ''}" id="pdp-wishlist-toggle" aria-label="Toggle Wishlist">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="${isWishlisted ? 'currentColor' : 'none'}" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                        d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/>
                </svg>
              </button>
            </div>

            <button class="btn btn--gold pdp-buy-now-btn" id="pdp-buy-now">
              Instant Reserve & Checkout
            </button>

            <!-- Luxury Concierge Features Bar -->
            <div style="background:var(--color-white); border:1px solid rgba(214,183,122,0.3); border-radius:var(--radius-xs); padding:16px; margin-bottom:28px; display:grid; grid-template-columns:1fr 1fr; gap:14px; font-size:0.75rem;">
              <div style="display:flex; align-items:center; gap:8px;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--color-gold)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                <span>Free Insured Express Shipping</span>
              </div>
              <div style="display:flex; align-items:center; gap:8px;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--color-gold)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <span>${product.longevity}</span>
              </div>
              <div style="display:flex; align-items:center; gap:8px;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--color-gold)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                <span>Signature Coffret Presentation</span>
              </div>
              <div style="display:flex; align-items:center; gap:8px;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--color-gold)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                <span>Grasse Master Craftsmanship</span>
              </div>
            </div>

            <!-- Olfactory Accordions -->
            <div class="pdp-accordions">
              <!-- Olfactory Architecture (Pyramid) -->
              <div class="accordion-item is-open">
                <button class="accordion-trigger" data-accordion>
                  <span>The Olfactory Architecture</span>
                  <span class="accordion-icon">+</span>
                </button>
                <div class="accordion-content">
                  <p style="margin-bottom:16px;">${product.description}</p>
                  
                  <div style="display:flex; flex-direction:column; gap:12px; background:var(--color-ivory); padding:16px; border-radius:var(--radius-xs); border:1px solid rgba(214,183,122,0.3);">
                    <div>
                      <strong style="color:var(--color-burgundy); font-family:var(--font-serif-display); font-size:0.8rem; letter-spacing:0.1em; text-transform:uppercase;">TOP NOTES (FIRST IMPRESSION):</strong>
                      <div class="tier-notes-tags" style="margin-top:4px;">
                        ${product.notes.top.map(n => `<span class="tier-note-pill">${n}</span>`).join('')}
                      </div>
                    </div>
                    <div>
                      <strong style="color:var(--color-burgundy); font-family:var(--font-serif-display); font-size:0.8rem; letter-spacing:0.1em; text-transform:uppercase;">HEART NOTES (SOUL & IDENTITY):</strong>
                      <div class="tier-notes-tags" style="margin-top:4px;">
                        ${product.notes.heart.map(n => `<span class="tier-note-pill">${n}</span>`).join('')}
                      </div>
                    </div>
                    <div>
                      <strong style="color:var(--color-burgundy); font-family:var(--font-serif-display); font-size:0.8rem; letter-spacing:0.1em; text-transform:uppercase;">BASE NOTES (ENDURING SILLAGE):</strong>
                      <div class="tier-notes-tags" style="margin-top:4px;">
                        ${product.notes.base.map(n => `<span class="tier-note-pill">${n}</span>`).join('')}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Application Ritual -->
              <div class="accordion-item">
                <button class="accordion-trigger" data-accordion>
                  <span>Application Ritual</span>
                  <span class="accordion-icon">+</span>
                </button>
                <div class="accordion-content">
                  <p>${product.ritual}</p>
                </div>
              </div>

              <!-- Formula & Ingredients -->
              <div class="accordion-item">
                <button class="accordion-trigger" data-accordion>
                  <span>Formulation & Safe Ingredients</span>
                  <span class="accordion-icon">+</span>
                </button>
                <div class="accordion-content">
                  <p style="margin-bottom:10px;">${product.ingredientsNotice}</p>
                  <p style="font-size:0.75rem; font-family:monospace; line-height:1.5;">${product.ingredients}</p>
                </div>
              </div>

              <!-- Delivery & Returns Policy -->
              <div class="accordion-item">
                <button class="accordion-trigger" data-accordion>
                  <span>Maison Delivery & Returns</span>
                  <span class="accordion-icon">+</span>
                </button>
                <div class="accordion-content">
                  <p>Each flacon is nestled in a signature velvet-lined SIFAZOO coffret. We include a complimentary 2ml discovery vial of your chosen fragrance with every order: test the vial first, and if not completely enamored, return the unopened 100ml flacon within 30 days for a full refund.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Related Creations -->
        <div style="margin-top:clamp(60px, 8vw, 100px); border-top:1px solid rgba(214,183,122,0.3); padding-top:50px;">
          <div class="section-label" style="justify-content:center;">COMPLEMENTARY HARMONIES</div>
          <h2 class="section-title" style="text-align:center; margin-bottom:40px;">You May Also Appreciate</h2>
          <div class="products-grid">
            ${related.map(p => this.createProductCardHTML(p)).join('')}
          </div>
        </div>
      </div>
    `;

    this.bindPdpInteractions(container, product);
  }

  bindPdpInteractions(container, product) {
    // Gallery Thumbnails
    const mainImg = container.querySelector('#pdp-main-img');
    container.querySelectorAll('[data-thumb]').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('[data-thumb]').forEach(b => b.classList.remove('is-active'));
        btn.classList.add('is-active');
        const src = btn.getAttribute('data-thumb');
        if (mainImg) mainImg.src = src;
      });
    });

    // Size Selection
    container.querySelectorAll('[data-pdp-size]').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('[data-pdp-size]').forEach(b => b.classList.remove('is-selected'));
        btn.classList.add('is-selected');
        this.currentPdpSize = btn.getAttribute('data-pdp-size');
        const price = product.prices[this.currentPdpSize];
        container.querySelector('#pdp-current-price').textContent = `$${price}`;
        container.querySelector('#pdp-selected-size-label').textContent = `${this.currentPdpSize} Extrait`;
      });
    });

    // Quantity Increment / Decrement
    const qtyVal = container.querySelector('#pdp-qty-val');
    container.querySelector('#pdp-qty-dec').addEventListener('click', () => {
      if (this.currentPdpQty > 1) {
        this.currentPdpQty--;
        qtyVal.textContent = this.currentPdpQty;
      }
    });
    container.querySelector('#pdp-qty-inc').addEventListener('click', () => {
      this.currentPdpQty++;
      qtyVal.textContent = this.currentPdpQty;
    });

    // Add to Bag
    container.querySelector('#pdp-submit-add').addEventListener('click', () => {
      window.sifazooStore.addToCart(product.id, this.currentPdpSize, this.currentPdpQty);
      this.openCartDrawer();
    });

    // Buy Now
    container.querySelector('#pdp-buy-now').addEventListener('click', () => {
      window.sifazooStore.addToCart(product.id, this.currentPdpSize, this.currentPdpQty);
      window.location.hash = '#checkout';
    });

    // Wishlist Toggle
    const wishlistBtn = container.querySelector('#pdp-wishlist-toggle');
    wishlistBtn.addEventListener('click', () => {
      const isAdded = window.sifazooStore.toggleWishlist(product.id);
      wishlistBtn.classList.toggle('is-active', isAdded);
      const svg = wishlistBtn.querySelector('svg');
      if (svg) svg.setAttribute('fill', isAdded ? 'currentColor' : 'none');
    });

    // Accordions
    container.querySelectorAll('[data-accordion]').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = btn.closest('.accordion-item');
        item.classList.toggle('is-open');
      });
    });

    // Related cards interactions
    this.attachCardInteractions(container);
  }

  // --- CART DRAWER RENDERING ---
  renderCartDrawer() {
    const list = document.getElementById('drawer-items-list');
    const footer = document.getElementById('drawer-footer-content');
    const progressFill = document.getElementById('drawer-shipping-progress');
    const shippingText = document.getElementById('drawer-shipping-text');
    if (!list) return;

    const summary = window.sifazooStore.getCartSummary();
    const cart = window.sifazooStore.cart;

    // Progress bar
    if (progressFill && shippingText) {
      progressFill.style.width = `${summary.progressToFreeShipping}%`;
      if (summary.isFreeShipping) {
        shippingText.innerHTML = `<strong>Privilege Unlocked:</strong> You qualify for Complimentary White-Glove Insured Delivery`;
      } else {
        shippingText.innerHTML = `Add <strong>$${summary.amountNeededForFreeShipping}</strong> more to enjoy Complimentary Insured Delivery`;
      }
    }

    if (cart.length === 0) {
      list.innerHTML = `
        <div class="drawer-empty-state">
          <svg class="drawer-empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
          </svg>
          <div class="drawer-empty-text">Your Shopping Bag is Empty</div>
          <p class="drawer-empty-subtext">Discover the sensory world of SIFAZOO and find your signature scent.</p>
          <a href="#shop" class="btn btn--gold" onclick="window.sifazooApp.closeCartDrawer()">Explore Collection</a>
        </div>
      `;
      if (footer) footer.style.display = 'none';
      return;
    }

    if (footer) footer.style.display = 'block';

    list.innerHTML = cart.map(item => `
      <div class="cart-item" data-cart-item="${item.productId}-${item.size}">
        <img class="cart-item-img" src="${item.image}" alt="${item.name}" />
        <div class="cart-item-details">
          <div>
            <div class="cart-item-name">${item.name}</div>
            <div class="cart-item-size">${item.size} · Extrait de Parfum</div>
            <div class="cart-item-price">$${item.price}</div>
          </div>
          <div class="cart-item-qty-row">
            <div class="qty-control">
              <button class="qty-btn" onclick="window.sifazooStore.updateQuantity('${item.productId}', '${item.size}', ${item.quantity - 1})">-</button>
              <span class="qty-num">${item.quantity}</span>
              <button class="qty-btn" onclick="window.sifazooStore.updateQuantity('${item.productId}', '${item.size}', ${item.quantity + 1})">+</button>
            </div>
            <button class="cart-item-remove-btn" onclick="window.sifazooStore.removeFromCart('${item.productId}', '${item.size}')">Remove</button>
          </div>
        </div>
      </div>
    `).join('');

    // Update Drawer Footer
    const subtotalEl = document.getElementById('drawer-subtotal-val');
    if (subtotalEl) subtotalEl.textContent = `$${summary.discountedSubtotal.toFixed(0)}`;
  }

  // --- CART PAGE VIEW ---
  renderCartPage() {
    const container = document.getElementById('cart-page-container');
    if (!container) return;

    const summary = window.sifazooStore.getCartSummary();
    const cart = window.sifazooStore.cart;

    if (cart.length === 0) {
      container.innerHTML = `
        <div style="text-align:center; padding:80px 20px;">
          <h2 class="section-title">Your Shopping Bag is Currently Empty</h2>
          <p class="section-subtitle" style="margin:0 auto 30px auto;">Each SIFAZOO flacon is an invitation to self-expression.</p>
          <a href="#shop" class="btn btn--gold">Discover the Collection</a>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div style="display:grid; grid-template-columns:1fr; gap:40px;" class="checkout-grid">
        <div>
          <h2 class="section-title" style="margin-bottom:24px;">Shopping Bag (${summary.count})</h2>
          
          <div style="background:var(--color-white); border:1px solid rgba(214,183,122,0.3); border-radius:var(--radius-xs); padding:24px;">
            ${cart.map(item => `
              <div style="display:grid; grid-template-columns:90px 1fr auto; gap:20px; padding:20px 0; border-bottom:1px solid #eee; align-items:center;">
                <img src="${item.image}" alt="${item.name}" style="width:90px; height:110px; object-fit:cover; border-radius:var(--radius-xs);" />
                <div>
                  <h3 class="product-title" style="font-size:1.1rem; margin-bottom:4px;">${item.name}</h3>
                  <div style="font-size:0.75rem; color:#777; margin-bottom:8px;">${item.size} · Extrait de Parfum</div>
                  <div class="qty-control">
                    <button class="qty-btn" onclick="window.sifazooStore.updateQuantity('${item.productId}', '${item.size}', ${item.quantity - 1})">-</button>
                    <span class="qty-num">${item.quantity}</span>
                    <button class="qty-btn" onclick="window.sifazooStore.updateQuantity('${item.productId}', '${item.size}', ${item.quantity + 1})">+</button>
                  </div>
                </div>
                <div style="text-align:right;">
                  <div style="font-family:var(--font-serif-display); font-size:1.15rem; font-weight:600; color:var(--color-burgundy);">$${item.price * item.quantity}</div>
                  <button class="cart-item-remove-btn" style="margin-top:12px;" onclick="window.sifazooStore.removeFromCart('${item.productId}', '${item.size}')">Remove</button>
                </div>
              </div>
            `).join('')}
          </div>

          <!-- Promo Code Box -->
          <div style="margin-top:24px; background:var(--color-white); border:1px solid rgba(214,183,122,0.3); padding:20px; border-radius:var(--radius-xs); display:flex; gap:12px;">
            <input type="text" id="promo-code-input" placeholder="Privilege Code (e.g. SIFAZOO10)" class="form-input" style="text-transform:uppercase;" value="${summary.discountCode || ''}" />
            <button class="btn btn--black" id="apply-promo-btn" style="padding:12px 24px;">Apply</button>
          </div>
        </div>

        <!-- Order Summary Card -->
        <div>
          <div class="checkout-card" style="position:sticky; top:110px;">
            <h3 class="footer-col-title" style="color:var(--color-black); margin-bottom:20px;">Order Summary</h3>
            <div style="display:flex; justify-content:space-between; margin-bottom:12px; font-size:0.88rem;">
              <span style="color:#666;">Subtotal</span>
              <span style="font-weight:600;">$${summary.subtotal.toFixed(0)}</span>
            </div>
            ${summary.discountAmount > 0 ? `
              <div style="display:flex; justify-content:space-between; margin-bottom:12px; font-size:0.88rem; color:var(--color-burgundy);">
                <span>Courtesy Privilege (${(summary.discountPercent * 100).toFixed(0)}%)</span>
                <span>-$${summary.discountAmount.toFixed(0)}</span>
              </div>
            ` : ''}
            <div style="display:flex; justify-content:space-between; margin-bottom:12px; font-size:0.88rem;">
              <span style="color:#666;">White Glove Delivery</span>
              <span>${summary.isFreeShipping ? '<span style="color:#2a7e4b; font-weight:600;">Complimentary</span>' : `$${summary.shippingFee}`}</span>
            </div>
            <div style="border-top:1px solid rgba(214,183,122,0.3); margin-top:16px; padding-top:16px; display:flex; justify-content:space-between; align-items:baseline; margin-bottom:24px;">
              <span style="font-family:var(--font-serif-display); font-size:1.1rem; font-weight:600;">Total</span>
              <span style="font-family:var(--font-serif-display); font-size:1.6rem; font-weight:600; color:var(--color-burgundy);">$${summary.total.toFixed(0)}</span>
            </div>
            <a href="#checkout" class="btn btn--burgundy" style="width:100%; height:52px;">Proceed to Secure Checkout</a>
            <div style="margin-top:16px; text-align:center; font-size:0.72rem; color:#888;">
              30-Day Sealed Returns Guarantee · Complimentary Signature Packaging
            </div>
          </div>
        </div>
      </div>
    `;

    // Promo code event
    const applyBtn = container.querySelector('#apply-promo-btn');
    const promoInput = container.querySelector('#promo-code-input');
    if (applyBtn && promoInput) {
      applyBtn.addEventListener('click', () => {
        const res = window.sifazooStore.applyPromoCode(promoInput.value);
        if (!res.success) {
          window.sifazooStore.showToast(res.message, 'error');
        }
      });
    }
  }

  // --- CHECKOUT VIEW ---
  renderCheckoutSummary() {
    const summaryEl = document.getElementById('checkout-order-summary');
    if (!summaryEl) return;

    const summary = window.sifazooStore.getCartSummary();
    const cart = window.sifazooStore.cart;

    if (cart.length === 0) {
      summaryEl.innerHTML = `
        <div style="text-align:center; padding:30px 10px;">
          <p>Your bag is empty. Please add items before checking out.</p>
          <a href="#shop" class="btn btn--gold" style="margin-top:14px;">Browse Fragrances</a>
        </div>
      `;
      return;
    }

    summaryEl.innerHTML = `
      <div style="display:flex; flex-direction:column; gap:14px; margin-bottom:20px; max-height:280px; overflow-y:auto;">
        ${cart.map(item => `
          <div style="display:flex; gap:12px; align-items:center;">
            <img src="${item.image}" alt="${item.name}" style="width:50px; height:60px; object-fit:cover; border-radius:var(--radius-xs);" />
            <div style="flex-grow:1;">
              <div style="font-size:0.85rem; font-weight:600;">${item.name}</div>
              <div style="font-size:0.72rem; color:#777;">${item.size} · Qty: ${item.quantity}</div>
            </div>
            <div style="font-family:var(--font-serif-display); font-size:0.95rem; font-weight:600;">$${item.price * item.quantity}</div>
          </div>
        `).join('')}
      </div>

      <div style="border-top:1px solid #eee; padding-top:14px; display:flex; flex-direction:column; gap:8px; font-size:0.82rem;">
        <div style="display:flex; justify-content:space-between;">
          <span style="color:#666;">Subtotal</span>
          <span>$${summary.subtotal.toFixed(0)}</span>
        </div>
        ${summary.discountAmount > 0 ? `
          <div style="display:flex; justify-content:space-between; color:var(--color-burgundy);">
            <span>Privilege Discount</span>
            <span>-$${summary.discountAmount.toFixed(0)}</span>
          </div>
        ` : ''}
        <div style="display:flex; justify-content:space-between;">
          <span style="color:#666;">Delivery</span>
          <span>${summary.isFreeShipping ? 'Complimentary' : `$${summary.shippingFee}`}</span>
        </div>
        <div style="border-top:1px solid rgba(214,183,122,0.3); padding-top:12px; margin-top:8px; display:flex; justify-content:space-between; align-items:baseline;">
          <span style="font-family:var(--font-serif-display); font-size:1.05rem; font-weight:600;">Total</span>
          <span style="font-family:var(--font-serif-display); font-size:1.45rem; font-weight:600; color:var(--color-burgundy);">$${summary.total.toFixed(0)}</span>
        </div>
      </div>
    `;
  }

  handleCheckoutSubmit(e) {
    e.preventDefault();
    const cart = window.sifazooStore.cart;
    if (cart.length === 0) {
      window.sifazooStore.showToast('Your shopping bag is empty.', 'error');
      return;
    }

    const form = e.target;
    const name = form.querySelector('[name="fullName"]')?.value || 'Distinguished Guest';
    const email = form.querySelector('[name="email"]')?.value || 'client@sifazoo.com';
    const address = form.querySelector('[name="address"]')?.value || 'Bespoke Residence';
    const city = form.querySelector('[name="city"]')?.value || 'Paris';
    const country = form.querySelector('[name="country"]')?.value || 'France';
    const summary = window.sifazooStore.getCartSummary();

    const orderId = `SFZ-${Math.floor(100000 + Math.random() * 900000)}`;

    // Show simulated confirmation modal with clear demonstration tag per requirements
    const modal = document.getElementById('order-confirmation-modal');
    const content = document.getElementById('order-confirmation-content');
    if (modal && content) {
      content.innerHTML = `
        <div style="text-align:center; padding:20px;">
          <div style="width:64px; height:64px; border-radius:50%; background:var(--color-burgundy); color:var(--color-gold); display:flex; align-items:center; justify-content:center; margin:0 auto 20px auto;">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
            </svg>
          </div>
          <div class="demo-mode-badge" style="display:inline-block; margin-bottom:16px;">
            ⚠️ DEMONSTRATION ORDER CONFIRMATION — No real currency charged
          </div>
          <h2 class="section-title" style="font-size:1.8rem; margin-bottom:8px;">Merci, ${name}</h2>
          <p style="font-size:0.9rem; color:#666; margin-bottom:24px;">
            Your demonstration order <strong>#${orderId}</strong> has been logged into the boutique atelier ledger.
          </p>

          <div style="background:var(--color-ivory); border:1px solid rgba(214,183,122,0.3); border-radius:var(--radius-xs); padding:20px; text-align:left; margin-bottom:24px; font-size:0.85rem;">
            <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
              <span style="color:#777;">Client:</span>
              <strong>${name} (${email})</strong>
            </div>
            <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
              <span style="color:#777;">Delivery Address:</span>
              <strong>${address}, ${city}, ${country}</strong>
            </div>
            <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
              <span style="color:#777;">Flacons Reserved:</span>
              <strong>${summary.count} Item${summary.count > 1 ? 's' : ''}</strong>
            </div>
            <div style="display:flex; justify-content:space-between; border-top:1px solid #ddd; padding-top:8px; margin-top:8px;">
              <span style="font-family:var(--font-serif-display); font-size:1rem; font-weight:600;">Total Amount:</span>
              <strong style="color:var(--color-burgundy); font-size:1.15rem;">$${summary.total.toFixed(0)}</strong>
            </div>
          </div>

          <p style="font-size:0.75rem; color:#888; margin-bottom:24px;">
            In production, live payment processing gateways (Stripe / Apple Pay / Adyen) will activate upon entry of merchant credentials.
          </p>

          <div style="display:flex; justify-content:center; gap:12px;">
            <button class="btn btn--gold" onclick="window.sifazooApp.finishDemoOrder()">Return to Boutique</button>
          </div>
        </div>
      `;

      modal.classList.add('is-open');
    }
  }

  finishDemoOrder() {
    const modal = document.getElementById('order-confirmation-modal');
    if (modal) modal.classList.remove('is-open');
    window.sifazooStore.clearCart();
    window.location.hash = '#home';
  }

  // --- WISHLIST VIEW ---
  renderWishlistPage() {
    const container = document.getElementById('wishlist-grid');
    if (!container) return;

    const products = window.sifazooStore.getWishlistProducts();

    if (products.length === 0) {
      container.innerHTML = `
        <div style="grid-column:1 / -1; text-align:center; padding:70px 20px;">
          <h2 class="section-title">Your Curated Wishlist is Empty</h2>
          <p class="section-subtitle" style="margin:0 auto 28px auto;">Save the fragrances that evoke your personal aesthetic.</p>
          <a href="#shop" class="btn btn--gold">Explore the Fragrance Library</a>
        </div>
      `;
      return;
    }

    container.innerHTML = products.map(p => this.createProductCardHTML(p)).join('');
    this.attachCardInteractions(container);
  }

  // --- SEARCH MODAL FILTER ---
  handleSearch(query) {
    const resultsContainer = document.getElementById('search-results');
    if (!resultsContainer) return;

    const q = (query || '').trim().toLowerCase();
    if (!q) {
      resultsContainer.innerHTML = `<p style="color:rgba(255,255,255,0.4); text-align:center; padding:20px;">Type a fragrance name, olfactive note (e.g. "Oud", "Rose", "Bergamot"), or category...</p>`;
      return;
    }

    const matches = SIFAZOO_PRODUCTS.filter(p => {
      const allNotes = [...p.notes.top, ...p.notes.heart, ...p.notes.base, ...p.accords].join(' ').toLowerCase();
      return (
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.family.toLowerCase().includes(q) ||
        allNotes.includes(q)
      );
    });

    if (matches.length === 0) {
      resultsContainer.innerHTML = `<p style="color:rgba(255,255,255,0.5); text-align:center; padding:20px;">No flacons found matching "${query}". Try searching for "Oud", "Rose", "Leather", or "Amber".</p>`;
      return;
    }

    resultsContainer.innerHTML = matches.map(p => `
      <div class="search-item-card" onclick="window.location.hash='#product/${p.id}'; window.sifazooApp.closeSearchModal();">
        <img class="search-item-thumb" src="${p.primaryImage}" alt="${p.name}" />
        <div>
          <div style="font-family:var(--font-serif-display); font-size:0.9rem; font-weight:600; color:var(--color-gold);">${p.name}</div>
          <div style="font-size:0.7rem; color:rgba(255,255,255,0.7);">${p.categoryLabel} · ${p.family}</div>
          <div style="font-size:0.8rem; font-weight:600; margin-top:2px;">$${p.prices['100ml']}</div>
        </div>
      </div>
    `).join('');
  }

  // --- INTERACTIVE SCENT FINDER QUIZ ---
  openQuizModal() {
    const modal = document.getElementById('quiz-modal');
    if (!modal) return;
    this.quizStep = 1;
    this.quizAnswers = {};
    this.renderQuizStep();
    modal.classList.add('is-open');
    document.body.style.overflow = 'hidden';
  }

  closeQuizModal() {
    const modal = document.getElementById('quiz-modal');
    if (modal) {
      modal.classList.remove('is-open');
      document.body.style.overflow = '';
    }
  }

  renderQuizStep() {
    const container = document.getElementById('quiz-content');
    if (!container) return;

    if (this.quizStep === 1) {
      container.innerHTML = `
        <div class="quiz-step-indicator">
          <div class="quiz-step-dot is-active"></div>
          <div class="quiz-step-dot"></div>
          <div class="quiz-step-dot"></div>
        </div>
        <h3 class="quiz-question-title">What atmosphere resonates with your spirit?</h3>
        <p class="quiz-question-sub">Step 1 of 3 · Olfactory Mood Diagnostic</p>
        <div class="quiz-options-grid">
          <button class="quiz-option-btn" onclick="window.sifazooApp.answerQuiz(1, 'woody')">
            <span class="quiz-option-name">Enigmatic Midnight Library</span>
            <span class="quiz-option-detail">Smoked oud, aged cedarwood, and antique leather bindings</span>
          </button>
          <button class="quiz-option-btn" onclick="window.sifazooApp.answerQuiz(1, 'floral')">
            <span class="quiz-option-name">Opulent Midnight Rose Garden</span>
            <span class="quiz-option-detail">Deep velvety Grasse petals, black truffle, and sensual florals</span>
          </button>
          <button class="quiz-option-btn" onclick="window.sifazooApp.answerQuiz(1, 'oriental')">
            <span class="quiz-option-name">Golden Sunset Sanctuary</span>
            <span class="quiz-option-detail">Warm honeyed resins, glowing amber, and bourbon vanilla</span>
          </button>
          <button class="quiz-option-btn" onclick="window.sifazooApp.answerQuiz(1, 'fresh')">
            <span class="quiz-option-name">Sunlit Riviera Breeze</span>
            <span class="quiz-option-detail">Calabrian citrus orchards, white neroli, and crisp skin musk</span>
          </button>
        </div>
      `;
    } else if (this.quizStep === 2) {
      container.innerHTML = `
        <div class="quiz-step-indicator">
          <div class="quiz-step-dot is-active"></div>
          <div class="quiz-step-dot is-active"></div>
          <div class="quiz-step-dot"></div>
        </div>
        <h3 class="quiz-question-title">What is your desired olfactive sillage?</h3>
        <p class="quiz-question-sub">Step 2 of 3 · Projection & Presence</p>
        <div class="quiz-options-grid">
          <button class="quiz-option-btn" onclick="window.sifazooApp.answerQuiz(2, 'subtle')">
            <span class="quiz-option-name">An Intimate Whisper</span>
            <span class="quiz-option-detail">Discreet, elegant second-skin aura noticed upon proximity</span>
          </button>
          <button class="quiz-option-btn" onclick="window.sifazooApp.answerQuiz(2, 'moderate')">
            <span class="quiz-option-name">Radiant & Luminous</span>
            <span class="quiz-option-detail">Harmonious trail that leaves an indelible, sophisticated memory</span>
          </button>
          <button class="quiz-option-btn" onclick="window.sifazooApp.answerQuiz(2, 'commanding')">
            <span class="quiz-option-name">Hypnotic & Commanding</span>
            <span class="quiz-option-detail">Opulent Extrait projection that commands the room</span>
          </button>
        </div>
      `;
    } else if (this.quizStep === 3) {
      container.innerHTML = `
        <div class="quiz-step-indicator">
          <div class="quiz-step-dot is-active"></div>
          <div class="quiz-step-dot is-active"></div>
          <div class="quiz-step-dot is-active"></div>
        </div>
        <h3 class="quiz-question-title">For which occasion do you seek this creation?</h3>
        <p class="quiz-question-sub">Step 3 of 3 · Signature Alignment</p>
        <div class="quiz-options-grid">
          <button class="quiz-option-btn" onclick="window.sifazooApp.answerQuiz(3, 'daily')">
            <span class="quiz-option-name">Personal Everyday Signature</span>
            <span class="quiz-option-detail">Elevated refinement for daily wear and quiet confidence</span>
          </button>
          <button class="quiz-option-btn" onclick="window.sifazooApp.answerQuiz(3, 'evening')">
            <span class="quiz-option-name">Black Tie Gala & Nocturnal Romance</span>
            <span class="quiz-option-detail">Dramatic allure for unforgettable evenings</span>
          </button>
          <button class="quiz-option-btn" onclick="window.sifazooApp.answerQuiz(3, 'connoisseur')">
            <span class="quiz-option-name">Rare Collector's Flacon</span>
            <span class="quiz-option-detail">Complex artistry for true fragrance connoisseurs</span>
          </button>
        </div>
      `;
    }
  }

  answerQuiz(step, value) {
    this.quizAnswers[step] = value;
    if (step < 3) {
      this.quizStep = step + 1;
      this.renderQuizStep();
    } else {
      this.showQuizResult();
    }
  }

  showQuizResult() {
    const container = document.getElementById('quiz-content');
    if (!container) return;

    // Recommendation logic based on answers
    let matchId = 'sifa-01'; // Default: L'Ombre Dorée
    const mood = this.quizAnswers[1];
    const sillage = this.quizAnswers[2];

    if (mood === 'woody') {
      matchId = sillage === 'commanding' ? 'sifa-03' : 'sifa-05';
    } else if (mood === 'floral') {
      matchId = sillage === 'commanding' ? 'sifa-02' : 'sifa-07';
    } else if (mood === 'oriental') {
      matchId = sillage === 'commanding' ? 'sifa-01' : 'sifa-04';
    } else if (mood === 'fresh') {
      matchId = sillage === 'subtle' ? 'sifa-12' : 'sifa-09';
    }

    const matchedProduct = SifazooCatalog.getById(matchId) || SifazooCatalog.getById('sifa-01');

    container.innerHTML = `
      <div style="text-align:center; padding:10px 0;">
        <span class="hero-brand-pill" style="margin-bottom:16px;">YOUR SIFAZOO SIGNATURE MATCH</span>
        <h2 class="section-title" style="margin-bottom:8px;">${matchedProduct.name}</h2>
        <p style="font-size:0.85rem; color:#777; margin-bottom:24px;">${matchedProduct.subtitle}</p>

        <div style="max-width:280px; margin:0 auto 20px auto; aspect-ratio:4/5; border-radius:var(--radius-xs); overflow:hidden; border:1px solid rgba(214,183,122,0.4); box-shadow:var(--shadow-card);">
          <img src="${matchedProduct.primaryImage}" alt="${matchedProduct.name}" style="width:100%; height:100%; object-fit:cover;" />
        </div>

        <p style="font-size:0.9rem; color:#444; line-height:1.6; max-width:480px; margin:0 auto 24px auto;">
          ${matchedProduct.description}
        </p>

        <div style="display:flex; justify-content:center; gap:12px; flex-wrap:wrap;">
          <a href="#product/${matchedProduct.id}" class="btn btn--burgundy" onclick="window.sifazooApp.closeQuizModal()">
            Discover ${matchedProduct.name}
          </a>
          <button class="btn btn--gold" onclick="window.sifazooStore.addToCart('${matchedProduct.id}', '100ml', 1); window.sifazooApp.closeQuizModal(); window.sifazooApp.openCartDrawer();">
            Add 100ml to Bag ($${matchedProduct.prices['100ml']})
          </button>
        </div>
      </div>
    `;
  }

  // --- NEWSLETTER & FORMS ---
  handleNewsletterSubmit(e) {
    e.preventDefault();
    const input = e.target.querySelector('input[type="email"]');
    if (!input) return;

    const email = input.value.trim();
    if (!email || !email.includes('@')) {
      window.sifazooStore.showToast('Please enter a valid email address.', 'error');
      return;
    }

    input.value = '';
    window.sifazooStore.showToast('Welcome to the World of SIFAZOO. A complimentary welcome privilege has been sent.', 'success');
  }

  handleContactSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const name = form.querySelector('[name="name"]')?.value;
    const email = form.querySelector('[name="email"]')?.value;
    const message = form.querySelector('[name="message"]')?.value;

    if (!name || !email || !message) {
      window.sifazooStore.showToast('Please complete all required fields.', 'error');
      return;
    }

    form.reset();
    window.sifazooStore.showToast('Your inquiry has been received by our private boutique concierge. We will reply within 24 hours.', 'success');
  }
}

// Instantiate App
document.addEventListener('DOMContentLoaded', () => {
  window.sifazooApp = new SifazooApp();
});


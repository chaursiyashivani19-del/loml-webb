/**
 * SIFAZOO HAUTE PARFUMERIE — Reactive Store & State Manager
 * Handles Cart, Wishlist, Notifications, Scent Quiz, and Demonstration Checkout.
 */

class SifazooStore {
  constructor() {
    this.cart = this.loadFromStorage('sifazoo_cart', []);
    this.wishlist = this.loadFromStorage('sifazoo_wishlist', []);
    this.discountCode = null;
    this.discountPercent = 0;
    this.includeGiftBox = false;
    this.freeShippingThreshold = 250;
    this.listeners = [];

    // Preload wishlist with 1 sample item if completely empty so user sees it populated immediately
    if (this.wishlist.length === 0) {
      this.wishlist = ['sifa-01', 'sifa-02'];
      this.saveToStorage('sifazoo_wishlist', this.wishlist);
    }
  }

  loadFromStorage(key, fallback) {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : fallback;
    } catch (e) {
      console.warn('LocalStorage unavailable:', e);
      return fallback;
    }
  }

  saveToStorage(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }

  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  notify() {
    this.listeners.forEach(fn => fn(this));
  }

  // --- CART MANAGEMENT ---
  addToCart(productId, size = '100ml', quantity = 1) {
    const product = SifazooCatalog.getById(productId);
    if (!product) return;

    const price = product.prices[size] || product.prices['100ml'];
    const existingIndex = this.cart.findIndex(item => item.productId === productId && item.size === size);

    if (existingIndex > -1) {
      this.cart[existingIndex].quantity += quantity;
    } else {
      this.cart.push({
        productId,
        name: product.name,
        subtitle: product.subtitle,
        size,
        price,
        image: product.primaryImage,
        quantity: Math.max(1, quantity)
      });
    }

    this.saveToStorage('sifazoo_cart', this.cart);
    this.notify();
    this.showToast(`Added to your bag: ${product.name} (${size})`, 'success');
  }

  updateQuantity(productId, size, quantity) {
    const itemIndex = this.cart.findIndex(i => i.productId === productId && i.size === size);
    if (itemIndex === -1) return;

    if (quantity <= 0) {
      this.removeFromCart(productId, size);
      return;
    }

    this.cart[itemIndex].quantity = quantity;
    this.saveToStorage('sifazoo_cart', this.cart);
    this.notify();
  }

  removeFromCart(productId, size) {
    const item = this.cart.find(i => i.productId === productId && i.size === size);
    this.cart = this.cart.filter(i => !(i.productId === productId && i.size === size));
    this.saveToStorage('sifazoo_cart', this.cart);
    this.notify();
    if (item) {
      this.showToast(`Removed from bag: ${item.name}`, 'info');
    }
  }

  clearCart() {
    this.cart = [];
    this.discountCode = null;
    this.discountPercent = 0;
    this.saveToStorage('sifazoo_cart', this.cart);
    this.notify();
  }

  getCartCount() {
    return this.cart.reduce((sum, item) => sum + item.quantity, 0);
  }

  getCartSubtotal() {
    return this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }

  applyPromoCode(code) {
    const cleanCode = (code || '').trim().toUpperCase();
    if (cleanCode === 'SIFAZOO10' || cleanCode === 'SIGNATURE10') {
      this.discountCode = cleanCode;
      this.discountPercent = 0.10;
      this.notify();
      this.showToast('Privilege code applied: 10% Maison Courtesy Savings', 'success');
      return { success: true, message: '10% privilege discount applied.' };
    } else if (cleanCode === 'HAUTE20') {
      this.discountCode = cleanCode;
      this.discountPercent = 0.20;
      this.notify();
      this.showToast('VIP Collector code applied: 20% Courtesy Savings', 'success');
      return { success: true, message: '20% VIP collector discount applied.' };
    } else {
      return { success: false, message: 'Invalid or expired privilege code.' };
    }
  }

  removePromoCode() {
    this.discountCode = null;
    this.discountPercent = 0;
    this.notify();
    this.showToast('Privilege code removed', 'info');
  }

  toggleGiftBox(include) {
    this.includeGiftBox = include !== undefined ? include : !this.includeGiftBox;
    this.notify();
  }

  getCartSummary() {
    const subtotal = this.getCartSubtotal();
    const discountAmount = subtotal * this.discountPercent;
    const discountedSubtotal = subtotal - discountAmount;
    const isFreeShipping = subtotal >= this.freeShippingThreshold || subtotal === 0;
    const shippingFee = isFreeShipping ? 0 : 25;
    const giftBoxFee = this.includeGiftBox && subtotal > 0 ? 15 : 0;
    const total = discountedSubtotal + shippingFee + giftBoxFee;
    const progressToFreeShipping = Math.min(100, Math.round((subtotal / this.freeShippingThreshold) * 100));
    const amountNeededForFreeShipping = Math.max(0, this.freeShippingThreshold - subtotal);

    return {
      subtotal,
      discountPercent: this.discountPercent,
      discountCode: this.discountCode,
      discountAmount,
      discountedSubtotal,
      shippingFee,
      isFreeShipping,
      progressToFreeShipping,
      amountNeededForFreeShipping,
      giftBoxFee,
      includeGiftBox: this.includeGiftBox,
      total,
      count: this.getCartCount()
    };
  }

  // --- WISHLIST MANAGEMENT ---
  toggleWishlist(productId) {
    const exists = this.wishlist.includes(productId);
    const product = SifazooCatalog.getById(productId);

    if (exists) {
      this.wishlist = this.wishlist.filter(id => id !== productId);
      this.saveToStorage('sifazoo_wishlist', this.wishlist);
      this.notify();
      this.showToast(`Removed from your Wishlist`, 'info');
      return false;
    } else {
      this.wishlist.push(productId);
      this.saveToStorage('sifazoo_wishlist', this.wishlist);
      this.notify();
      this.showToast(`Saved to your Wishlist: ${product ? product.name : ''}`, 'success');
      return true;
    }
  }

  isInWishlist(productId) {
    return this.wishlist.includes(productId);
  }

  getWishlistCount() {
    return this.wishlist.length;
  }

  getWishlistProducts() {
    return this.wishlist
      .map(id => SifazooCatalog.getById(id))
      .filter(Boolean);
  }

  // --- TOAST NOTIFICATION SYSTEM ---
  showToast(message, type = 'info', actionText = null, actionCallback = null) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `luxury-toast luxury-toast--${type} enter`;
    
    let iconSvg = '';
    if (type === 'success') {
      iconSvg = `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>`;
    } else if (type === 'error') {
      iconSvg = `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10" stroke-width="2"/><line x1="12" y1="8" x2="12" y2="12" stroke-width="2"/><line x1="12" y1="16" x2="12.01" y2="16" stroke-width="2"/></svg>`;
    } else {
      iconSvg = `<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10" stroke-width="2"/><line x1="12" y1="16" x2="12" y2="12" stroke-width="2"/><line x1="12" y1="8" x2="12.01" y2="8" stroke-width="2"/></svg>`;
    }

    toast.innerHTML = `
      <div class="toast-content">
        ${iconSvg}
        <span class="toast-text">${message}</span>
      </div>
      ${actionText ? `<button class="toast-action-btn">${actionText}</button>` : ''}
      <button class="toast-close-btn" aria-label="Close notification">&times;</button>
    `;

    if (actionText && actionCallback) {
      toast.querySelector('.toast-action-btn').addEventListener('click', () => {
        actionCallback();
        toast.remove();
      });
    }

    toast.querySelector('.toast-close-btn').addEventListener('click', () => {
      toast.classList.remove('enter');
      toast.classList.add('exit');
      setTimeout(() => toast.remove(), 300);
    });

    container.appendChild(toast);

    setTimeout(() => {
      if (toast.parentElement) {
        toast.classList.remove('enter');
        toast.classList.add('exit');
        setTimeout(() => toast.remove(), 300);
      }
    }, 4200);
  }
}

// Global store instance
const store = new SifazooStore();
window.sifazooStore = store;


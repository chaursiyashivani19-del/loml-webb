# SIFAZOO — Haute Parfumerie E-Commerce Website

> **"BEYOND FRAGRANCE. BE YOUR SIGNATURE."**
> A modern luxury perfume e-commerce experience celebrating individuality, sophistication, and haute parfumerie craftsmanship.

---

## 1. Brand Identity & Design System

- **Brand Name**: SIFAZOO
- **Industry**: Luxury Perfumes and Fragrances
- **Brand Positioning**: Modern luxury, elegance, sophistication, and individuality.
- **Design Direction**: Luxury Minimalist with subtle futuristic and architectural touches.
- **Brand Personality**: Elegant, Premium, Mysterious, Sophisticated, Modern, Memorable.

### Carefully Curated Colour Palette
| Tone | Hex Code | Purpose |
|---|---|---|
| **Champagne Gold** | `#D6B77A` | Subtle accents, borders, icons, seals, badges, and button highlights |
| **Warm Ivory** | `#F8F5EF` | Editorial backgrounds, soft card surfaces, and tactile sections |
| **Soft Blush** | `#EAD8D4` | Delicate accents and notification backgrounds |
| **Deep Burgundy** | `#4A1728` | Dramatic luxury sections, announcement bars, primary CTAs, and active states |
| **Rich Black** | `#171515` | Strong typography, cinematic campaign hero backgrounds, and dark contrast |
| **Pure White** | `#FFFFFF` | Clean editorial catalog surfaces and crisp typography readability |

---

## 2. Complete Website Structure (15 Pages + Interactive Suites)

1. **Home** (`index.html#home` or `/`)
   - **Announcement Bar**: Slim luxury bar: *"Discover Your Signature Scent | Explore SIFAZOO"*
   - **Navigation Header**: Sticky glass header with gold seal emblem, links (Home, Shop, Men, Women, Unisex, About, Contact), Live Search, Concierge, Wishlist badge counter, and Shopping Bag counter.
   - **Hero Section**: Cinematic perfume campaign with studio lighting, gold reflections, deep burgundy & obsidian background, and minimal typography: *"BEYOND FRAGRANCE. BE YOUR SIGNATURE."*
   - **Featured Collections**: Curated cards for Men's, Women's, and Unisex collections with image zoom and gold borders.
   - **Best Sellers**: Curated product grid featuring *L'Ombre Dorée*, *Rose Nocturne*, *Cuir Céleste*, and *Éclat d'Ambre*.
   - **Brand Story**: Refined editorial storytelling on individuality and olfactory architecture without invented historical claims: *"MORE THAN A FRAGRANCE. IT'S AN IDENTITY."*
   - **Signature Experience**: Interactive 3-Act Olfactory Architecture visualizer (Top, Heart, and Base notes).
   - **Promotional Banner**: *"FIND THE SCENT THAT FEELS LIKE YOU."*
   - **Customer Reviews**: Refined testimonials clearly labeled as salon trial/demonstration placeholders per brand guidelines.
   - **Newsletter**: *"ENTER THE WORLD OF SIFAZOO."* with email validation and privacy notice.
   - **Footer**: Brand description, quick navigation, concierge desk, payment badges (Visa, Mastercard, Amex, Apple Pay), and copyright.

2. **Shop All** (`shop.html` or `index.html#shop`)
   - Complete catalog of 12 luxury creations with sorting (Featured, Newest, Price: Low to High, Price: High to Low) and category pills.

3. **Men's Fragrances** (`index.html#men`)
   - Architectural leather, noble woods, and smoked incense tailored for commanding poise (*Cuir Céleste*, *Santal Impérial*, *Nuit Mystique*, *Tobacco Royale*).

4. **Women's Fragrances** (`index.html#women`)
   - Intoxicating centifolia florals, rare Madagascan vanillas, and velvet evening accords (*Rose Nocturne*, *Fleur d'Ivoire*, *Soleil de Grasse*).

5. **Unisex Fragrances** (`index.html#unisex`)
   - Genderless olfactive poetry: pure orris, mineral amber, and sacred woods (*L'Ombre Dorée*, *Éclat d'Ambre*, *Velvet Santal*, *Iris Céleste*, *Musc Pur*).

6. **Product Details** (`product.html` or `index.html#product/:id`)
   - Multi-angle high-resolution gallery with interactive thumbnails
   - Volume selector: 50ml, 100ml, 200ml Extrait with instant price recalculation
   - Quantity selector, Add to Bag, Buy Now, and Wishlist toggles
   - Interactive Accordions:
     - The Olfactory Architecture (Top, Heart, and Base note pills)
     - Application Ritual guidance
     - Formulation & INCI cosmetic ingredients disclosure
     - Maison Delivery & Returns with 30-Day Sealed Flacon Policy
   - Complementary Harmonies (Related products grid)

7. **About SIFAZOO** (`about.html` or `index.html#about`)
   - The House calling, 30% Pure Extrait standard, sustainable sourcing from Grasse and Madagascar, and heavy architectural Italian glass flacons.

8. **Contact Us** (`contact.html` or `index.html#contact`)
   - Concierge inquiry form with real-time field validation
   - Global Flagship Atelier addresses: Paris (Place Vendôme), London (Old Bond Street), Dubai (The Dubai Mall)
   - Direct concierge phone and email desk.

9. **Shopping Bag** (`cart.html` or `index.html#cart`)
   - Full page shopping bag + slide-out drawer
   - Real-time quantity adjustments, item removals, subtotal calculation
   - Complimentary White-Glove Shipping progress indicator ($250 threshold)
   - Privilege code redemption (e.g. `SIFAZOO10` for 10% courtesy savings)

10. **Checkout Flow** (`checkout.html` or `index.html#checkout`)
    - 3-step luxury checkout (Client Information, Delivery Address, Payment Selection)
    - Transparent demonstration mode badge per guidelines
    - Order summary and instant receipt modal generation.

11. **Wishlist** (`wishlist.html` or `index.html#wishlist`)
    - Persistent collection saved in `localStorage`
    - Instant Add to Bag and Remove actions.

12. **FAQ** (`faq.html` or `index.html#faq`)
    - Interactive accordion covering fragrance concentration, the 2ml discovery vial policy, storage recommendations, and bespoke engraving.

13. **Shipping & Returns** (`shipping-returns.html` or `index.html#shipping`)
    - Climate-controlled insured express dispatch details and 30-day sealed return guarantee.

14. **Privacy Policy** (`privacy-policy.html` or `index.html#privacy`)
    - Client confidentiality, zero data-selling policy, and security protocols.

15. **Terms & Conditions** (`terms-conditions.html` or `index.html#terms`)
    - Terms of boutique use, batch variations, and intellectual property.

---

## 3. Bonus Luxury Features

- **✦ The Signature Scent Finder Quiz**: An interactive 3-step diagnostic modal that matches the customer's mood, preferred sillage, and occasion with their ideal SIFAZOO flacon.
- **✦ Quick View Modal**: Preview olfactory notes and add to bag directly from any catalog grid without navigating away.
- **✦ Live Search Bar**: Real-time search by fragrance title, gender, family, or raw notes (e.g. "Oud", "Rose", "Leather", "Amber").
- **✦ Luxury Toast Notifications**: Custom slide-in notifications with golden borders and icons confirming cart and wishlist actions.

---

## 4. Backend Architecture & API Endpoints

A lightweight, robust backend is provided via `server.php`:
- `POST /api/newsletter`: Validates email and logs subscription with welcome privilege code.
- `POST /api/contact`: Validates and logs concierge consultation inquiries into `data_inquiries.json` with unique ticket ID.
- `POST /api/order`: Logs demonstration orders into `data_orders.json` with simulated order ID and invoice breakdown.
- `GET /`: Serves the application with optimized HTTP headers, mime types, and static asset handling.

---

## 5. How to Run & Preview the Website

### Option A: Using the Included PHP Server (Recommended)
1. Run the local server command from the project root:
   ```powershell
   & "C:\Users\Admin\AppData\Local\Programs\Local\resources\extraResources\lightning-services\php-8.2.29+0\bin\win64\php.exe" -S localhost:8080 server.php
   ```
2. Open your browser and navigate to:
   ```
   http://localhost:8080
   ```

### Option B: Direct Browser Opening
Simply double-click or open `index.html` in Google Chrome, Microsoft Edge, Safari, or Firefox. All state management, routing, and catalog interactions work natively out of the box via modern ES6 standards.

---

## 6. Technical Standards & SEO
- **Semantic HTML5** with accessible ARIA labels.
- **Responsive Mobile-First CSS** with CSS Custom Properties, smooth easing curves, and flex/grid layouts.
- **Schema.org JSON-LD** metadata for Luxury Brand indexing.
- **OpenGraph & Twitter Card** social tags.
- **XML Sitemap** (`sitemap.xml`) and **Robots.txt** (`robots.txt`).
- Zero dependencies required: pure, clean, maintainable vanilla JavaScript & CSS.

